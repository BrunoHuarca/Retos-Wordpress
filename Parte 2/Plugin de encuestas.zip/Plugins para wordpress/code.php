<?php
/*
Plugin Name: Encuestas rapidas
Description: Plugin creado para crear encuestas rapidas y anonimas.
Version: 1.0
Author: Bruno Huarca Bustinza
*/

if (!defined('ABSPATH')) {
    exit; 
}

// Crear una tabla en la base de datos al activar el plugin
function encuesta_crear_tabla() {
    global $wpdb;
    $tabla_encuestas = $wpdb->prefix . 'encuestas';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $tabla_encuestas (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        pregunta varchar(255) NOT NULL,
        opcion1 varchar(255) NOT NULL,
        opcion2 varchar(255) NOT NULL,
        opcion3 varchar(255),
        opcion4 varchar(255),
        votos_opcion1 int(9) DEFAULT 0,
        votos_opcion2 int(9) DEFAULT 0,
        votos_opcion3 int(9) DEFAULT 0,
        votos_opcion4 int(9) DEFAULT 0,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

register_activation_hook(__FILE__, 'encuesta_crear_tabla');

// Añadir el menú en el panel de administración
function encuesta_agregar_menu() {
    add_menu_page(
        'Encuestas',
        'Encuestas',
        'manage_options',
        'encuestas-wp',
        'encuesta_render_admin_page',
        'dashicons-chart-bar',
        6
    );
}
add_action('admin_menu', 'encuesta_agregar_menu');

// Página de administración
function encuesta_render_admin_page() {
    global $wpdb;
    $tabla_encuestas = $wpdb->prefix . 'encuestas';

    if (isset($_POST['nueva_encuesta'])) {
        $pregunta = sanitize_text_field($_POST['pregunta']);
        $opcion1 = sanitize_text_field($_POST['opcion1']);
        $opcion2 = sanitize_text_field($_POST['opcion2']);
        $opcion3 = sanitize_text_field($_POST['opcion3']);
        $opcion4 = sanitize_text_field($_POST['opcion4']);

        $wpdb->insert(
            $tabla_encuestas,
            array(
                'pregunta' => $pregunta,
                'opcion1' => $opcion1,
                'opcion2' => $opcion2,
                'opcion3' => $opcion3,
                'opcion4' => $opcion4
            )
        );

        echo '<div class="notice notice-success is-dismissible">
                <p>Encuesta creada exitosamente.</p>
              </div>';
    }

    echo '<div class="wrap">';
    echo '<h1>Crear Nueva Encuesta</h1>';
    echo '<form method="post">';
    echo '<table class="form-table">
            <tr>
                <th scope="row"><label for="pregunta">Pregunta</label></th>
                <td><input type="text" id="pregunta" name="pregunta" class="regular-text" required></td>
            </tr>
            <tr>
                <th scope="row"><label for="opcion1">Opción 1</label></th>
                <td><input type="text" id="opcion1" name="opcion1" class="regular-text" required></td>
            </tr>
            <tr>
                <th scope="row"><label for="opcion2">Opción 2</label></th>
                <td><input type="text" id="opcion2" name="opcion2" class="regular-text" required></td>
            </tr>
            <tr>
                <th scope="row"><label for="opcion3">Opción 3</label></th>
                <td><input type="text" id="opcion3" name="opcion3" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row"><label for="opcion4">Opción 4</label></th>
                <td><input type="text" id="opcion4" name="opcion4" class="regular-text"></td>
            </tr>
        </table>';
    echo '<p><input type="submit" name="nueva_encuesta" class="button button-primary" value="Crear Encuesta"></p>';
    echo '</form>';
    echo '</div>';

    
     // Mostrar encuestas y resultados
     echo '<div class="wrap">';
     echo '<h1>Resultados de las Encuestas</h1>';
     $encuestas = $wpdb->get_results("SELECT * FROM $tabla_encuestas");
 
     if ($encuestas) {
         echo '<table class="widefat fixed" cellspacing="0">';
         echo '<thead><tr><th>Pregunta</th><th>Opción 1</th><th>Opción 2</th><th>Opción 3</th><th>Opción 4</th><th>Votos Opción 1</th><th>Votos Opción 2</th><th>Votos Opción 3</th><th>Votos Opción 4</th></tr></thead>';
         echo '<tbody>';
 
         foreach ($encuestas as $encuesta) {
             echo '<tr>';
             echo '<td>' . esc_html($encuesta->pregunta) . '</td>';
             echo '<td>' . esc_html($encuesta->opcion1) . '</td>';
             echo '<td>' . esc_html($encuesta->opcion2) . '</td>';
             echo '<td>' . esc_html($encuesta->opcion3) . '</td>';
             echo '<td>' . esc_html($encuesta->opcion4) . '</td>';
             echo '<td>' . esc_html($encuesta->votos_opcion1) . '</td>';
             echo '<td>' . esc_html($encuesta->votos_opcion2) . '</td>';
             echo '<td>' . esc_html($encuesta->votos_opcion3) . '</td>';
             echo '<td>' . esc_html($encuesta->votos_opcion4) . '</td>';
             echo '</tr>';
         }
 
         echo '</tbody>';
         echo '</table>';
     } else {
         echo '<p>No hay encuestas disponibles.</p>';
     }
 
     echo '</div>';
 }

// Mostrar encuesta en el frontend con un shortcode
function encuesta_mostrar_shortcode($atts) {
    global $wpdb;
    $tabla_encuestas = $wpdb->prefix . 'encuestas';

    // Obtener la encuesta más reciente
    $encuesta = $wpdb->get_row("SELECT * FROM $tabla_encuestas ORDER BY id DESC LIMIT 1");

    if ($encuesta) {
        $html = '<form method="post">';
        $html .= '<p>' . esc_html($encuesta->pregunta) . '</p>';
        $html .= '<p><input type="radio" name="respuesta" value="1"> ' . esc_html($encuesta->opcion1) . '</p>';
        $html .= '<p><input type="radio" name="respuesta" value="2"> ' . esc_html($encuesta->opcion2) . '</p>';
        if (!empty($encuesta->opcion3)) {
            $html .= '<p><input type="radio" name="respuesta" value="3"> ' . esc_html($encuesta->opcion3) . '</p>';
        }
        if (!empty($encuesta->opcion4)) {
            $html .= '<p><input type="radio" name="respuesta" value="4"> ' . esc_html($encuesta->opcion4) . '</p>';
        }
        $html .= '<p><input type="submit" name="votar_encuesta" value="Votar"></p>';
        $html .= '</form>';

        return $html;
    }

    return '<p>No hay encuestas disponibles en este momento.</p>';
}

add_shortcode('mostrar_encuesta', 'encuesta_mostrar_shortcode');

// Procesar votos
function encuesta_procesar_voto() {
    global $wpdb;
    $tabla_encuestas = $wpdb->prefix . 'encuestas';

    if (isset($_POST['votar_encuesta']) && isset($_POST['respuesta'])) {
        $respuesta = intval($_POST['respuesta']);
        $encuesta = $wpdb->get_row("SELECT * FROM $tabla_encuestas ORDER BY id DESC LIMIT 1");

        if ($encuesta) {
            if ($respuesta == 1) {
                $wpdb->update($tabla_encuestas, array('votos_opcion1' => $encuesta->votos_opcion1 + 1), array('id' => $encuesta->id));
            } elseif ($respuesta == 2) {
                $wpdb->update($tabla_encuestas, array('votos_opcion2' => $encuesta->votos_opcion2 + 1), array('id' => $encuesta->id));
            } elseif ($respuesta == 3) {
                $wpdb->update($tabla_encuestas, array('votos_opcion3' => $encuesta->votos_opcion3 + 1), array('id' => $encuesta->id));
            } elseif ($respuesta == 4) {
                $wpdb->update($tabla_encuestas, array('votos_opcion4' => $encuesta->votos_opcion4 + 1), array('id' => $encuesta->id));
            }
        }
    }
}

add_action('init', 'encuesta_procesar_voto');
